EXERPIA WALLET — ANDROID PROJECT STARTER
Package: com.exerpia.app
Version: 1.0.0 (versionCode 1)

IMPORTANT
This ZIP is Android source code, not a compiled .aab file. It is a starter/demo app.
It does not connect to a real XRP wallet, sign transactions, or process payments.

BUILD THE APP BUNDLE IN ANDROID STUDIO
1. Extract this ZIP.
2. Open Android Studio and choose Open, then select the extracted ExerpiaWalletAndroid folder.
3. Allow Gradle sync to finish. If Android Studio asks to install Android SDK Platform 35, install it.
4. Select Build > Generate Signed Bundle / APK.
5. Choose Android App Bundle, then Next.
6. Create or select a release signing key. Keep the keystore and passwords private and backed up.
7. Choose the release build variant and finish.
8. Android Studio should create the bundle under app/release/ (commonly app-release.aab).
9. Upload that .aab file to Google Play Console > Internal testing > Create release.

Before distribution, test the app and complete Play Console's required app content, data safety,
privacy policy, testing, and other declarations. Do not describe demo-only functions as live wallet
or payment functionality.

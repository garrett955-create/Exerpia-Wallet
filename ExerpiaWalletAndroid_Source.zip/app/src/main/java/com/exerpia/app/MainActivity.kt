package com.exerpia.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val navy = Color.rgb(18, 31, 56)
    private val blue = Color.rgb(45, 105, 220)
    private val pale = Color.rgb(242, 246, 252)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = navy
        window.navigationBarColor = navy
        window.decorView.systemUiVisibility = 0

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(pale)
            setPadding(dp(22), dp(24), dp(22), dp(20))
        }

        val brand = TextView(this).apply {
            text = "EXERPIA"
            textSize = 14f
            setTextColor(blue)
            letterSpacing = 0.18f
        }
        root.addView(brand)

        val title = TextView(this).apply {
            text = "Wallet"
            textSize = 32f
            setTextColor(navy)
            setPadding(0, dp(6), 0, dp(18))
        }
        root.addView(title)

        val balanceCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(navy)
            setPadding(dp(20), dp(20), dp(20), dp(22))
        }
        addText(balanceCard, "TOTAL BALANCE", 13f, Color.LTGRAY)
        addText(balanceCard, "Demo wallet", 27f, Color.WHITE)
        addText(balanceCard, "No real funds connected", 14f, Color.LTGRAY)
        root.addView(balanceCard, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(18)
        })

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        actions.addView(action("Receive XRP") { showMessage(root, "Demo receive screen — connect a verified XRPL wallet before handling real funds.") },
            LinearLayout.LayoutParams(0, dp(54), 1f).apply { rightMargin = dp(6) })
        actions.addView(action("Send") { showMessage(root, "Sending is not enabled in this demo.") },
            LinearLayout.LayoutParams(0, dp(54), 1f).apply { leftMargin = dp(6) })
        root.addView(actions)

        val section = TextView(this).apply {
            text = "Wallet activity"
            textSize = 21f
            setTextColor(navy)
            setPadding(0, dp(26), 0, dp(10))
        }
        root.addView(section)
        addPanel(root, "Transaction history", "Your transactions will appear here.")
        addPanel(root, "Way Token (WAT)", "Concept screen — no token balance is connected.")
        addPanel(root, "Smart Faucet", "Payment concept preview — payments are not enabled.")

        val footer = TextView(this).apply {
            text = "EXERPIA WALLET • INTERNAL TEST BUILD"
            textSize = 11f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(22), 0, dp(4))
        }
        root.addView(footer)
        setContentView(root)
    }

    private fun addText(parent: LinearLayout, value: String, size: Float, color: Int) {
        parent.addView(TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            setPadding(0, dp(3), 0, dp(5))
        })
    }

    private fun addPanel(root: LinearLayout, heading: String, description: String) {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            setPadding(dp(15), dp(13), dp(15), dp(13))
        }
        addText(panel, heading, 16f, navy)
        addText(panel, description, 13f, Color.DKGRAY)
        root.addView(panel, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(9)
        })
    }

    private fun action(label: String, onClick: () -> Unit): View =
        TextView(this).apply {
            text = label
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setBackgroundColor(blue)
            setOnClickListener { onClick() }
        }

    private fun showMessage(root: LinearLayout, message: String) {
        android.widget.Toast.makeText(this, message, android.widget.Toast.LENGTH_LONG).show()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
